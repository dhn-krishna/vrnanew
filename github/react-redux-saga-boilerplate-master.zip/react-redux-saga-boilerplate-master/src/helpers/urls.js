export const urls = {
    'LOGIN_URL': '/auth/login',
    'REGISTER_URL': '/auth/register',
    'BOOK': '/book',
    'VERIFY_CONFIRM_OTP': '/auth/verify-otp',
    'RESEND_CONFIRM_OTP': '/auth/resend-verify-otp'
} 